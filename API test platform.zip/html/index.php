<?php include './layout/header.php'; ?>

	<div class="header" id="canvas_wrap" style="display: inline-block;">
		<canvas id="canvas"></canvas>
	</div>

	<div class="container shadow">
		<div class="index-columns">
			<div class="index-column shadow">
				<h2>SDK</h2>
			</div>

			<div class="index-column shadow">
				<h2>TOOLS</h2>
			</div>

			<div class="index-column shadow">
				<h2>DOCS</h2>
			</div>
		</div>
	</div>

<?php include './layout/footer.php'; ?>
